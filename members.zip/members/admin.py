from django.contrib import admin
from .models import Members


admin.site.register(Members)